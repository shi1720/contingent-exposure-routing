Contingent Exposure Routing for Financial AI
Shivam Gupta

Main file: main.tex. Compile with pdfLaTeX and BibTeX, or Tectonic.
A generated main.bbl is included. Six figures are vector PDFs.
Manuscript and constructed research data: CC BY 4.0.
Code and complete data: https://github.com/shi1720/contingent-exposure-routing
This package is prepared source, not evidence of submission or acceptance.
